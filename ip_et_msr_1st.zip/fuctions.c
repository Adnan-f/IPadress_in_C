#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "head.h"

void head() 
{
    printf("Content-Type:text/html\n\n");
    printf("<html><head><meta charset=\"UTF-8\" /><title>IP</title><link rel=\"stylesheet\" href=\"styles.css\"></head><body>");
}

char *ip_comp(int a, int b, int c, int d) 
{
    static char class[20];
    if (a<0 || a>255 || b<0 || b>255 || c<0 || c>255 || d<0 || d>255) 
    {
        strcpy(class, "IP Invalide");
    } 
    else if (a>=0 && a<=127) 
    {
        strcpy(class, "class A");
    } 
    else if (a>=128 && a<=191) 
    {
        strcpy(class, "class B");
    } 
    else if (a>=192 && a<=223) 
    {
        strcpy(class, "class C");
    } 
    else if (a>=224 && a<=239) 
    {
        strcpy(class, "class D");
    } 
    else if (a>=240 && a<=255) 
    {
        strcpy(class, "class E");
    } 
    else 
    {
        strcpy(class, "IP Invalide");
    }
    return class;
}

char *default_msr(int a, int b, int c, int d) 
{
    static char msr[20];
    char *classe=ip_comp(a, b, c, d);
    if (strcmp(classe, "class A")==0) 
    {
        strcpy(msr, "255.0.0.0");
    } 
    else if (strcmp(classe, "class B")==0) 
    {
        strcpy(msr, "255.255.0.0");
    } 
    else if (strcmp(classe, "class C")==0) 
    {
        strcpy(msr, "255.255.255.0");
    } 
    else 
    {
        strcpy(msr, "Inconnu");
    }
    return msr;
}

void gerer_net(int a, int b, int c, int d) 
{
    char address_net[MAX_CHAR];
    char *classe=ip_comp(a, b, c, d);

    if (strcmp(classe, "class A")==0) 
    {
        strcpy(address_net, "Réseau A");
    } 
    else if (strcmp(classe, "class B")==0) 
    {
        strcpy(address_net, "Réseau B");
    } 
    else if (strcmp(classe, "class C")==0) 
    {
        strcpy(address_net, "Réseau C");
    } 
    else 
    {
        strcpy(address_net, "Classe non prise en charge");
        printf("<p>%s</p>", address_net);
    }
}

void address_calc(int a, int b, int c, int d, const char *msr, char *reseau, char *broadcast) 
{
    int msr_div[4];
    int ip_div[4]={a, b, c, d};
    int network_div[4], broadcast_div[4];

    // Convertir le masque de sous-réseau en entiers
    sscanf(msr, "%d.%d.%d.%d", &msr_div[0], &msr_div[1], &msr_div[2], &msr_div[3]);

    // Calculer l'adresse réseau
    for (int i=0; i<4; i++) 
    {
        network_div[i]=ip_div[i] & msr_div[i];
    }

    // Calculer l'adresse de diffusion
    for (int i=0; i<4; i++) 
    {
        broadcast_div[i]=ip_div[i] | (~msr_div[i] & 255);
    }

    // Formater les adresses en chaînes de caractères
    sprintf(reseau, "%d.%d.%d.%d", network_div[0], network_div[1], network_div[2], network_div[3]);
    sprintf(broadcast, "%d.%d.%d.%d", broadcast_div[0], broadcast_div[1], broadcast_div[2], broadcast_div[3]);
}

void get_data() 
{
    char *data=getenv("QUERY_STRING");
    if (data==NULL) 
    {
        printf("<p>Erreur lors de l'analyse des données.</p>");
        printf("<button><a href=\"index.html\">Réessayer</a></button>");
        printf("</body></html>");
        exit(1);
    }

    char msr[MAX_CHAR];
    char *classe;
    int a, b, c, d;
    char reseau[MAX_CHAR];
    char broadcast[MAX_CHAR];

    // Analyse des données de la requête GET
    int ip_str=sscanf(data, "ip=%d.%d.%d.%d&msr=%s", &a, &b, &c, &d, msr);

    if (ip_str==5) 
    {
        char *msr_default=default_msr(a, b, c, d);
        if (strcmp(msr, msr_default)!=0) 
        {
            printf("<p>Masque de sous-réseau inconnu</p>");
            printf("<button><a href=\"index.html\">Réessayer</a></button>");
            printf("</body></html>");
            exit(1);
        } 
        else 
        {
            classe=ip_comp(a, b, c, d);
            address_calc(a, b, c, d, msr, reseau, broadcast);

            // Affichage dans un tableau HTML
            printf("<table border=\"1\">");
            printf("<tr><td><strong>IP</strong></td><td><strong>MSR</strong></td></tr>");
            printf("<tr><td>%d.%d.%d.%d</td><td>%s</td></tr>", a, b, c, d, msr);
            printf("</table>");

            printf("<table border=\"1\">");
            printf("<br><tr><td><strong>Type</strong></td><td><strong>Adresse</strong></td></tr><br>");
            printf("<br><tr><td>Adresse Réseau</td><td>%s</td></tr><br>", reseau);
            printf("<tr><td>Adresse de Diffusion</td><td>%s</td></tr>", broadcast);
            printf("</table>");
            
            printf("<p><strong>Classe:</strong> %s</p>", classe);
            
            gerer_net(a, b, c, d);
        }
    } 
    else 
    {
        printf("<p>Adresse IP invalide</p>");
        printf("<button><a href=\"index.html\">Réessayer</a></button>");
    }

    printf("</body></html>");
}
