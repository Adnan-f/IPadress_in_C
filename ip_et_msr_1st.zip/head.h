#ifndef HEAD_H
#define HEAD_H

#define MAX_CHAR 250

void head();
void get_data();
char *ip_comp(int a, int b, int c, int d);
char *default_msr(int a, int b, int c, int d);
void gerer_net(int a, int b, int c, int d);
void address_calc(int a, int b, int c, int d, const char *msr, char *reseau, char *broadcast);

#endif
