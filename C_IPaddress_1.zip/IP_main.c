#include "head.h"

int main() 
{
    head();
    get_data();
    return 0;
}

